# Lada website

A one-file website for **Lada** (clothing, bathrobes and swimwear, Hořovice).
Created by Terry and Spud. The page text is in Czech.

## Files

| File | What it is | Needed for hosting? |
|---|---|---|
| `index.html` | The whole website (HTML, CSS, JavaScript and the background picture in one file) | **Yes, this is the only file you upload** |
| `database.rules.json` | Security rules for the Firebase database | No, you paste it into the Firebase console |
| `main.html` | The old first version of the shop page (3 tabs, placeholder photos), kept as a backup. It can be deleted | No |
| `README.md` | This file | No |

## Hosting

Upload `index.html` to the root of any static host, for example GitHub Pages, Netlify (drag and drop) or Cloudflare Pages. No server, build step or extra files are needed. You can also just double-click `index.html` to open it on your own computer.

### GitHub Pages (from your fork)

1. In your fork, click **Add file > Upload files** and drop in `index.html`, `database.rules.json` and `README.md` from this folder (`main.html` stays exactly as it is in your repo). GitHub will replace the existing `index.html` and `README.md`. Then click **Commit changes**.
2. Open **Settings > Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then **Save**.
4. After a minute or two the site is live at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

GitHub Pages serves `index.html` as the home page automatically.

## Pages (tabs)

Top row:

1. **O nás** - what the shop sells, opening hours, address and a Mapy.cz button
2. **Katalog** - four products with sorting (A-Z, price low to high, price high to low)
3. **Kontakt** - phone number and address
4. **Číslo** - a box where you type a number; it shows the number back
5. **Zpráva** - contact form (phone, e-mail, message) that saves to a database
6. **Bazárek** - "Bazárek / Vetešnictví" page saying "Přidáme později" (we'll add it later)

Second row, buttons **0 to 9**, each opening an empty page with just its number, except:

- **6** - a page called "Odkazy" with clickable web addresses (placeholder links)
- **7** - only a big flickering neon **FOR SALE** sign

Button 6 is bold and green. Button 7 is bold and gets a new random color every time the page is refreshed.

## Summary of all changes

1. Started from the existing Lada shop page (About, Catalog, Contact tabs).
2. Added the **Číslo** tab with a number box.
3. Added the **Zpráva** tab with phone, e-mail and message boxes, connected to a simple database.
4. Added the **Bazárek / Vetešnictví** tab with the text "Přidáme později".
5. Added the **second row of buttons 0-9** with empty numbered pages.
6. Buttons 6 and 7 made bold; 7 gets a random color on every refresh, 6 stays green.
7. Navigation wraps onto more lines on phones so nothing overflows.
8. **Funky Lada logo**: bold Comic Sans, pastel letters in different colors, tilted, with a hover bounce.
9. **Background**: a cartoon house in a city, drawn as an SVG (not an AI-generated image), fixed behind the whole page. All cards, the header and the form boxes are semi-transparent with a blur.
10. **Hidden signature** "Created by Terry and Spud": an HTML comment at the top, an `author` meta tag, and a nearly invisible text in the bottom-right corner that appears on hover.
11. **Security features** (see below).
12. **Page 6** filled with links and **page 7** with the neon FOR SALE sign.
13. **Product photos** from the GitHub repo's `index.html` merged in (Triko, Mikina, Plavky, Kalhoty). Photos keep their proportions. If a photo fails to load, the "Fotografie produktu" placeholder is shown instead. The security policy allows images from only `images.unsplash.com` and `cdn.discordapp.com`.

## Database setup (Firebase Realtime Database)

Until you do this, messages from the form are only saved in the visitor's own browser.

1. Go to console.firebase.google.com and create a project.
2. Open **Build > Realtime Database > Create database**.
3. Copy the database URL (it ends in `firebasedatabase.app` or `firebaseio.com`).
4. In `index.html`, paste it between the quotes in `const DATABASE_URL = '';`.
5. In the database's **Rules** tab, paste the contents of `database.rules.json` and publish.
6. Read the messages in the Firebase console, under the `messages` folder.

### Why there is no password in the code

Everything in `index.html` can be read by every visitor, so a password placed there would not protect anything. Protection comes from the Firebase rules, which run on Google's servers:

- The website can only **add** new messages. It cannot read, change or delete any.
- Each message must have exactly a phone, e-mail, message and date, within length limits.
- Only the owner of the Firebase (Google) account can read the messages. Turn on 2-step verification for that account.

## Security features in the page

- Content Security Policy (blocks outside scripts and frames; only Firebase connections allowed). If you later add something from another website (fonts, maps, images), loosen the policy for it.
- No referrer sent; external links use `rel="noopener noreferrer"`.
- The form limits lengths, checks phone and e-mail format, has a hidden trap field for bots and a 30-second wait between messages. These browser-side checks can be bypassed by a determined person, so the Firebase rules are the real protection.
- Page text is always inserted as plain text, never as HTML.
- Some protections (for example blocking embedding in other sites) can only be set on the hosting side, not in the HTML.

## Easy edits

- **Products**: copy a `product-card` block in the Katalog tab; set `data-name` and `data-price`.
- **Links on page 6**: change the address in both places inside each `<li>`.
- **Opening hours, phone, address**: search for them in `index.html` and edit the text.
- **Wording of the second-row buttons**: change the number between `<button ...>` and `</button>`, and the `<h2>` on its page.
- **Own background image**: delete the `<svg class="bg-art"> ... </svg>` block and add `background: url('background.jpg') center / cover fixed;` inside `body { ... }`.
- **Signature**: search for `Terry and Spud`.

## Good to know

- Comic Sans comes with Windows and Mac; some Android phones and Linux computers show a similar rounded fallback font instead.
- **The Triko photo link has expired.** It is a Discord link, and Discord links stop working after a while (this one expired on 1 November 2026), so that card shows the placeholder text. To fix it, create an `images` folder in the repo, upload the photo there as `triko.png`, and change the `src` of the Triko `<img>` to `images/triko.png`. No policy change is needed for your own files.
- The Mikina, Plavky and Kalhoty photos come from Unsplash. They work, but they are sample pictures, so replace them with your own products when you can.
- Sample links on page 6 and the sample text in the shop are placeholders to replace with your own.
